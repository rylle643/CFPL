#include <stdio.h>

void main()
{
    float squaremeters, hectare;
    printf("Input a number in square meters: ");
    scanf ("%f", &squaremeters);
    
    hectare = squaremeters/10000;
    
    printf("equivalent measure in hectares is: %0.5f has\n", hectare);

    return 0;
