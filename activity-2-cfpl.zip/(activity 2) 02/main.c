#include <stdio.h>
#define Pi 3.1416

void main() 
{
    float radius, area;

    printf("Enter the radius of the circle: ");
    scanf("%f", &radius);

    area = Pi*radius*radius;

    printf("The area of the circle with radius %.2f cm is %.2f cm^2\n", radius, area);

    return 0;
}