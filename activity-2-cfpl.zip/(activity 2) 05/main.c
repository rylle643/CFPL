#include <stdio.h>

void main()
{
    float kilowatt, watt;
    
    printf ("Input a number in kilowatt: ");
    scanf ("%f", &kilowatt);
    
    watt = kilowatt*1000;
    
    printf ("The equivalent measure in watts is: %0.2f watts\n" ,watt);

    return 0;
}
