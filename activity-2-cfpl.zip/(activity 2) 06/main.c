#include <stdio.h>

void main()
{
    float side, area;
    
    printf ("Input the value of the side to compute the area of the square: ");
    scanf ("%f", &side);
    
    area = side*side;
    
    printf ("The total area of square is: %0.2f\n", area);

    return 0;
}
