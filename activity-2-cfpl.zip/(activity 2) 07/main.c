#include <stdio.h>

void main()
{
    float inch, feet;
    
    printf("Input a number in inches: ");
    scanf ("%f", &inch);
    
    feet = inch/12;
    
    printf ("The equivalent value in feet is: %0.2f ft\n", feet);

    return 0;
}
