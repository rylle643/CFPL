#include <stdio.h>

void main() 
{
    float minorA, midtermexam, midtermgrade;

    printf("Enter the minor A exam grade: ");
    scanf("%f", &minorA);

    printf("Enter the midterm exam grade: ");
    scanf("%f", &midtermexam);

    midtermgrade = (1.0/3.0)*minorA + (2.0/3.0)*midtermexam;

    printf("The midterm grade is: %.2f\n", midtermgrade);

    return 0;
}