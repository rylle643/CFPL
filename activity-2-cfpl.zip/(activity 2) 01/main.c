#include<stdio.h>

void main()
{
 float kilometer, meter;

 printf("Enter distance in kilometer: ");
 scanf("%f", &kilometer);

 meter = kilometer*1000;

 printf("%0.2f Kilometers = %0.2f Meters", kilometer, meter);

 return 0;
}