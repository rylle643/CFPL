#include <stdio.h>

int main()
{
    float base, height, area;
    printf ("Input the value of the base of the rectangle: ");
    scanf ("%f", &base);
    
    printf ("Input the value of the height of the rectangle: ");
    scanf ("%f", &height);
    
    area = base*height;
    
    printf ("The total area of the rectangle is: %0.2f\n", area);

    return 0;
}
