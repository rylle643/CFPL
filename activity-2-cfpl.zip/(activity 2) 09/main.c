#include <stdio.h>

void main()
{
    float num1, num2, num;
    printf("Input the value of Number 1: ");
    scanf ("%f", &num1);
    
    printf("Input the value of Number 2: ");
    scanf ("%f", &num2);
    
    num = num1;
    num1 = num2;
    num2 = num;
    
    printf ("Number 1: %.f\n", num1);
    printf ("Number 2: %.f\n", num);
    
    return 0;
}
